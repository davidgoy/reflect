<footer class="footer mt-auto py-3">
  <div class="container">

    <p class="clearfix text-center text-muted"><small><?php echo $config['siteCopyrightStatement']; ?></small></p>

  </div>
</footer>
