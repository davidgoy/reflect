<main role="main" class="container-fluid">

  <div id="mainContent" >
    <div class="row">
      <div class="col mx-auto">
        <div id="errorContent">
          <h2 class="text-center m-5">PAGE NOT FOUND</h2>
          <p class="text-center m-5">The page you are looking for does not exist, has been removed or its URL has changed.</p>
        </div>
      </div>
    </div>
  </div>

</main>
